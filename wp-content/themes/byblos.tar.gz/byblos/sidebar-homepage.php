<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package byblos
 */
?>
<div id="secondary" class="widget-area" role="complementary">
    <?php if (!dynamic_sidebar('sidebar-homepage')) : ?>
    
    
    
    
    <?php endif; // end sidebar widget area ?>
</div><!-- #secondary -->
