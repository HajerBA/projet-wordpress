<?php

/*
 * Short description
 * @author bilal hassan <info@smartcatdesign.net>
 * 
 */
?>
<div id="secondary" class="widget-area" role="complementary">
    <?php if (!dynamic_sidebar('sidebar-footer')) : ?>
    
    
    
    
    <?php endif; // end sidebar widget area ?>
</div><!-- #secondary -->
