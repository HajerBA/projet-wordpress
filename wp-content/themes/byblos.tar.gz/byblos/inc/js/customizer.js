jQuery( document ).ready( function( $ ){

    $('#customize-info .preview-notice').html('<a class="button button-primary" href="http://byblos.smartcatdev.wpengine.com" target="_BLANK">Upgrade to Byblos Pro</a>');
    $('#customize-info .preview-notice').append('<p style="color: #cc0000">The pro version includes unlimited skin colors, 6-slide advanced customizable slider, more font options, alternative callout design, more widget areas, contact form widget, Photo Gallery, Call to actions, Pricing widgets, Events and more!</p>');

});